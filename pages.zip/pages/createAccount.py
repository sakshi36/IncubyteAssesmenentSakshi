from pages.base import BasePage


class CreateAccoPage(BasePage):
    def __init__(self, page):
        self.page = page
        self.firstname = page.locator("#firstname")
        self.lastname = page.locator("#lastname")
        self.email = page.locator("#email_address")
        self.password = page.locator("#password")
        self.confirm_password = page.locator("#password-confirmation")
        self.create_btn = page.locator("button[title='Create an Account']")

    def fill_signup_form(self, fname, lname, email, pwd):
        self.firstname.fill(fname)
        self.lastname.fill(lname)
        self.email.fill(email)
        self.password.fill(pwd)
        self.confirm_password.fill(pwd)
        self.create_btn.click()

    def verify_signup_success(self):
        return self.page.locator("text=Thank you for registering with Main Website Store.").is_visible()

class BasePage:

    def __init__(self, page):
        self.page = page


    def close_ads_popup(self):
        try:
            with self.page.expect_popup(timeout=5000):
                pass  # Skip popup opening
            popup = self.page.locator("iframe[title='Advertisement']").first
            if popup.is_visible():
                self.page.frame_locator("iframe[title='Advertisement']").locator("button[aria-label='Close']").click(
                    timeout=5000)
                print("Ad popup closed.")
        except Exception:
            print("No Google Ad popup detected.")

from pages.base import BasePage


class HomePage(BasePage):
    def __init__(self, page):
        super().__init__(page)

    def go_create_acc(self):
        self.page.goto("https://magento.softwaretestingboard.com/", wait_until="domcontentloaded")
        self.page.wait_for_load_state("networkidle")
        self.page.wait_for_timeout(2000)

        # Step 2: Click "Create an Account"
        self.page.click("text=Create an Account")
        self.page.wait_for_load_state()

    def go_login(self):
        self.page.goto("https://magento.softwaretestingboard.com/")
        self.page.click("text=Sign In")
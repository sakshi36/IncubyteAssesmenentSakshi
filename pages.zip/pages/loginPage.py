from pages.base import BasePage


class LoginPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.email = page.locator("input#email")
        self.password = page.locator("input#pass")
        self.login_btn = page.locator("#send2")


    def login(self, email, password):
        self.email.fill(email)
        self.password.fill(password)
        self.login_btn.click()

    def verify_login_success(self, fname):
        return self.page.locator(f"text=Welcome, {fname}").is_visible()
from patchright.sync_api import expect
from playwright.sync_api import Playwright, expect, Page

name = "Clover01"
last_name = "Liver"
email = "clover02@yopmail.com"
password = "password@123"
confirm_pwd = "password@123"


def test_signUp(playwright: Playwright):
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://magento.softwaretestingboard.com/", wait_until="load")

    page.get_by_role("link", name="Create an Account").click()
    # handle adversitments
    # Try to close the ad popup
    for frame in page.frames:
        if "google_vignette" in frame.url:
            try:
                frame.locator("button[aria-label='Close']").click()
                print("Ad closed.")
            except:
                print("Close button not found in ad.")
            break
    #handle_ads(page)
    page.wait_for_timeout(3000)

    # assertion
    expect(page.get_by_text("Create New Customer Account")).to_be_visible()
    print("--------------Personal info-------------------")
    page.get_by_label("First Name").fill(name)
    page.get_by_label("Last Name").fill(last_name)

    print("----------------Sign-in inform------------------")
    page.get_by_role("textbox", name="Email").fill(email)
    page.locator("label[for='password']").fill(password)
    page.get_by_label("Confirm Password").fill(confirm_pwd)
    page.get_by_role("button", name="Create an Account").click()

    page.get_by_text("Thank you for registering with Main Website Store.").all_text_contents()

    page.locator(".customer-welcome").click()
    page.get_by_text("Sign Out").click()

    page.wait_for_timeout(2000)


def test_existing_user(page: Page):
    page.get_by_role("link", name="Sign In").click()
    page.get_by_label("Email").fill(email)
    page.locator("label[for='password']").fill(password)
    page.locator("#send2").click()
    page.wait_for_timeout(2000)

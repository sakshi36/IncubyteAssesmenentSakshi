from playwright.sync_api import sync_playwright
import time
import random
import string


def generate_random_user():
    first_name = "User" + ''.join(random.choices(string.ascii_letters, k=5))
    last_name = "Test" + ''.join(random.choices(string.ascii_letters, k=5))
    email = f"{first_name.lower()}.{last_name.lower()}@example.com"
    password = "Test@1234"
    return first_name, last_name, email, password


def close_ads_popup(page):
    try:
        with page.expect_popup(timeout=5000):
            pass  # Skip popup opening
        popup = page.locator("iframe[title='Advertisement']").first
        if popup.is_visible():
            page.frame_locator("iframe[title='Advertisement']").locator("button[aria-label='Close']").click(timeout=5000)
            print("Ad popup closed.")
    except Exception:
        print("No Google Ad popup detected.")


def  test_signup_and_login():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        # Step 1: Navigate to Magento site
        page.goto("https://magento.softwaretestingboard.com/",wait_until="domcontentloaded")
        page.wait_for_load_state("networkidle")
        page.wait_for_timeout(2000)

        # Step 2: Click "Create an Account"
        page.click("text=Create an Account")
        page.wait_for_load_state()

        # Step 3: Handle Google Ad popup (if any)
        close_ads_popup(page)

        # Step 4: Fill Sign-Up form
        first_name, last_name, email, password = generate_random_user()
        print(f"Signing up with: {email}")

        page.fill("#firstname", first_name)
        page.fill("#lastname", last_name)
        page.fill("#email_address", email)
        page.fill("#password", password)
        page.fill("#password-confirmation", password)
        page.click("button[title='Create an Account']")

        # Step 5: Verify registration success
        page.wait_for_selector("text=Thank you for registering with Main Website Store.", timeout=10000)
        print("Sign-Up Successful!")

        # Step 6: Logout
        page.hover("text=Welcome")
        page.click("//button[@data-action='customer-menu-toggle']")
        page.click("text=Sign Out")
        page.wait_for_selector("text=You are signed out")

        # Step 7: Sign In
        page.click("text=Sign In")
        page.fill("input#email", email)
        page.fill("input#pass", password)
        page.click("button#send2")

        # Step 8: Verify login success
        page.wait_for_selector(f"text=Welcome, {first_name}")
        print("Login Successful!")
        page.hover("text=Welcome")
        page.click("//button[@data-action='customer-menu-toggle']")
        page.click("text=Sign Out")

        browser.close()


if __name__ == "__main__":
    test_signup_and_login()

import random
import string


def generate_random_user():
    first_name = "User" + ''.join(random.choices(string.ascii_letters, k=5))
    last_name = "Test" + ''.join(random.choices(string.ascii_letters, k=5))
    email = f"{first_name.lower()}.{last_name.lower()}@example.com"
    password = "Test@1234"
    return first_name, last_name, email, password
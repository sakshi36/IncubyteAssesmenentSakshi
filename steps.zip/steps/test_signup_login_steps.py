from pytest_bdd import scenarios, given, when, then

from pages.createAccount import CreateAccoPage
from pages.home import HomePage
from pages.loginPage import LoginPage
from utils.data_generate import generate_random_user
import pytest

scenarios('../features/signup_login.feature')

# Shared variables
@pytest.fixture(scope='function')
def context():
    return {}


@given("the user opens the Magento homepage")
def open_homepage(setup, context):
    page = setup
    context['page'] = page
    context['home'] = HomePage(page)
    context['create'] = CreateAccoPage(page)
    context['login'] = LoginPage(page)
    context['first'], context['last'], context['email'], context['pwd'] = generate_random_user()
    context['home'].goto_create_account()
    context['create'].close_ad_popup()


@when("the user signs up with valid data")
def signup(context):
    context['create'].fill_signup_form(context['first'], context['last'], context['email'], context['pwd'])
    assert context['create'].verify_signup_success(), "Signup failed!"


@when("logs out")
def logout(context):
    page = context['page']
    page.hover("text=Welcome")
    page.click("text=Sign Out")
    page.wait_for_selector("text=You are signed out")


@then("the user logs in with the same credentials")
def login(context):
    context['home'].goto_login()
    context['login'].close_ad_popup()
    context['login'].login(context['email'], context['pwd'])


@then("sees a welcome message")
def verify_login(context):
    assert context['login'].verify_login_success(context['first']), "Login failed!"
